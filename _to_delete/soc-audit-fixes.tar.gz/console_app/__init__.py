# -*- coding: utf-8 -*-
"""СБОРКА КОНСОЛИ ЗАЩИТЫ.

create_app() создаёт Flask-приложение, подключает разделы (blueprints) и
поднимает фоновые потоки. Разделы соответствуют экранам консоли:

    security    вход, сессия, заголовки безопасности
    overview    обзор, лента алертов, каталог правил, запрос к данным
    incidents   инциденты, вердикты, дела, отчёты
    attack      покрытие ATT&CK, профили акторов, Red Launcher
    metrics     тренды, ROI, сводка для руководства, наука
    system      диагностика, здоровье, онбординг, демо

Зачем разделение. Раньше всё это было одним файлом console.py на 1841 строку:
маршруты, стрим-ингестор, триаж, генерация HTML-отчётов и воркеры вперемешку.
Дефекты, которые проект уже ловил на себе, — «половина панели осталась
прочерками», «счётчик противоречит содержимому» — рождаются именно так:
правка одного экрана требует удерживать в голове весь файл, и связь
теряется молча.

Порядок регистрации значения не имеет: маршруты не пересекаются, а
before_request аутентификации объявлен через before_app_request и потому
действует на всё приложение независимо от того, каким по счёту подключён
раздел security.
"""
from flask import Flask

import soclog
import websec

from . import core
from . import security, overview, incidents, attack, metrics, system, ingest

__all__ = ["create_app", "core"]

#: Разделы в порядке появления в меню консоли — так же они читаются и здесь.
_SECTIONS = (security.bp, overview.bp, incidents.bp, attack.bp,
             metrics.bp, system.bp)


def create_app(start_workers=True):
    """Собрать приложение.

    start_workers=False нужен тестам и инструментам, которые поднимают
    приложение только чтобы обойти маршруты: фоновые потоки при этом полезут
    в хранилище событий и в сеть, а проверяется не это. Раньше такой
    возможности не было — console.py стартовал ингестор прямо на импорте, и
    любой импорт модуля запускал чтение журнала.
    """
    # static_folder указывается ЯВНО и от корня проекта.
    #
    # Flask выводит его из __name__: пока приложение создавалось в console.py в
    # корне, папка сама попадала в <корень>/static. После переезда сборки в
    # пакет __name__ стал "console_app", и Flask начал искать статику в
    # console_app/static — такой папки нет, поэтому ВСЯ статика консоли отдавала
    # 404: страница логина рендерилась без единого стиля и с битым логотипом.
    #
    # Тесты этого не поймали: они проверяли, что файлы, на которые ссылается
    # разметка, ЛЕЖАТ НА ДИСКЕ, но ни разу не запрашивали их по HTTP. Теперь
    # запрашивают (tests/test_routes.py).
    # СТРУКТУРНОЕ ЛОГИРОВАНИЕ — ЗДЕСЬ, А НЕ ГДЕ-ТО ЕЩЁ.
    #
    # soclog.install() звался в webapp.py, main.py, run_defense.run() и
    # tools/doctor.py — и НИ РАЗУ в процессе консоли защиты. Консоль импортирует
    # run_defense ради process()/observed(), но run() не вызывает, поэтому
    # установка не происходила. Проверено на живом процессе:
    #
    #   GET :8788/api/diag -> {"installed": false, "paths": {}, "counts": {},
    #                          "errors": [], "recent": []}
    #
    # То есть страница «Диагностика» ИМЕННО ТОГО процесса, который крутит
    # детектор, коррелятор и LLM-триаж, была пуста всегда, logs/errors-console.log
    # не создавался, а каждое исключение из цикла ингеста (_flog.error с
    # exc_info) уходило в stderr и пропадало. Продукт не мог наблюдать сам себя.
    #
    # Регрессия появилась при выносе console.py в пакет: точка входа переехала,
    # вызов остался в старом файле.
    soclog.install(base_dir=core.ROOT)

    app = Flask(__name__, static_folder=core.ROOT + "/static", static_url_path="/static")
    # Отдельное имя cookie: cookie не разделяются по портам, и с общим именем
    # «session» две консоли на 127.0.0.1 перетирали друг другу атрибуты.
    websec.setup_app(app, "sentinel_console")

    @app.errorhandler(websec.BadArg)
    def _bad_arg(e):
        from flask import jsonify
        return jsonify({"error": "bad_request", "field": e.name,
                        "detail": e.detail}), 400

    # Защита от межсайтовых запросов. У этой консоли её не было вовсе — при том
    # что именно здесь запускаются атакующие кампании, заводятся issue в GitLab
    # и выставляются вердикты, три из которых глушат правило детектирования.
    app.before_request(websec.csrf_protect(exempt_paths={"/login"}))

    @app.after_request
    def _csrf_cookie(resp):
        return websec.issue_csrf(resp)

    for bp in _SECTIONS:
        app.register_blueprint(bp)

    if start_workers:
        ingest.start_workers()

    return app
