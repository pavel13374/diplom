# -*- coding: utf-8 -*-
"""Диагностика, здоровье, онбординг, демо

Часть консоли защиты. Вынесено из console.py: там 1841 строка держала
маршруты, ингест, триаж и сборку отчётов в одном файле, и правка одного
раздела требовала удерживать в голове все остальные.

Состояние и общие хелперы — в console_app.core, оно ЕДИНСТВЕННОЕ на процесс
и импортируется по имени: объекты (_COR, _STATE, _LOCK) создаются один раз
при импорте core и никогда не переприсваиваются, поэтому у всех разделов
общий экземпляр, а не копии.
"""

import time
import threading
import config
import eventstore
import soclog
from flask import Blueprint, jsonify, request

# Общее состояние консоли — ЯВНО, а не через `import *`:
# видно, чем раздел пользуется, и статический анализ снова работает.
from .core import _COR, _DEMO, _HEALTH, _LOCK, _STATE, _flog

# Демо-прогон крутится фоновым потоком из ingest.
from .ingest import _demo_worker


bp = Blueprint("system", __name__)

@bp.route("/api/diag")
def api_diag():
    """Диагностика: счётчики уровней, последние ошибки, хвост структурного лога."""
    d = soclog.diag()
    d["errors_log_tail"] = soclog.tail_errors(60)
    return jsonify(d)

def _ollama_ok():
    if time.time() - _HEALTH["ts"] > 30:
        try:
            import llm_client
            _HEALTH["ollama"] = bool(llm_client.available())
        except Exception:
            _HEALTH["ollama"] = False
        _HEALTH["ts"] = time.time()
    return _HEALTH["ollama"]

@bp.route("/api/health")
def api_health():
    import datetime as _dt
    st = eventstore.stats()
    last = eventstore.last_event()
    age = None
    if last and last.get("ts"):
        try:
            age = max(0, int((_dt.datetime.now()
                              - _dt.datetime.fromisoformat(last["ts"])).total_seconds()))
        except Exception:
            age = None
    with _LOCK:
        running = _STATE["running"]; processed = _STATE["processed"]
    # ПРИЧИНА, А НЕ НОЛЬ.
    #
    # При недоступном event-store всё это раньше отдавало нули, и «база не
    # открылась» выглядело точно так же, как «мир ещё не запускали». Теперь
    # ошибка доходит до интерфейса отдельным полем.
    store_err = None
    try:
        store_err = eventstore.last_error()
    except Exception:
        _flog.error("не удалось прочитать состояние event-store", exc_info=True)
    return jsonify({
        "world_alive": age is not None and age < 180,
        "events": {"total": st.get("events", 0), "last": last, "last_age_s": age},
        "store_ok": bool(st.get("enabled")),
        "store_error": store_err,
        "defense": {"running": running, "processed": processed},
        "ollama": _ollama_ok(),
        "auto_triage": bool(getattr(config, "LLM_AUTO_TRIAGE", True)),
    })

@bp.route("/api/demo", methods=["GET", "POST"])
def api_demo():
    if request.method == "POST" and not _DEMO["running"]:
        _DEMO.update(running=True, msg="генерирую демо-поток (норма + 2 кампании)…", rc=None)
        threading.Thread(target=_demo_worker, daemon=True).start()
    return jsonify(_DEMO)

@bp.route("/api/onboarding")
def api_onboarding():
    import datetime as _dt
    st = eventstore.stats()
    last = eventstore.last_event()
    age = None
    if last and last.get("ts"):
        try:
            age = max(0, int((_dt.datetime.now()
                              - _dt.datetime.fromisoformat(last["ts"])).total_seconds()))
        except Exception:
            age = None
    with _LOCK:
        alerts = _STATE["alerts_total"]
    _COR.summary()
    try:
        triaged = sum(1 for i in list(_COR.incidents.values()) if i.get("triage"))
    except Exception:
        triaged = 0
    return jsonify({
        "s1_world": (age is not None and age < 180) or _DEMO["running"],
        "s2_events": st.get("events", 0) > 0,
        "s3_campaign": st.get("campaigns", 0) > 0,
        "s4_alerts": alerts > 0,
        "s5_triage": triaged > 0,
        "demo": _DEMO,
    })

