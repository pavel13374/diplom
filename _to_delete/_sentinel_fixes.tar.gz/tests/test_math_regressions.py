#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
РЕГРЕССИИ ЧИСЛЕННОГО АППАРАТА.

Каждая проверка здесь закрывает КОНКРЕТНЫЙ найденный дефект, а не «математику
вообще». Формулировка задачи в каждом блоке — что именно было сломано, чтобы
через полгода правка не вернула то же самое как «упрощение».

Эталоны берутся из закрытых форм и рекуррентных соотношений, а НЕ из scipy:
модуль stats.py намеренно на stdlib, и тест не должен требовать того, чего не
требует код. Совпадение со scipy/statsmodels/sklearn проверялось отдельно при
разборе и зафиксировано в комментариях числами.

Запуск: python tests/test_math_regressions.py
"""
import os
import sys
import math

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("SOC_OFFLINE", "1")

import stats                                    # noqa: E402
import detector                                 # noqa: E402
import ml_features                              # noqa: E402
import taxonomy                                 # noqa: E402

FAILED = []


def check(name, ok, detail=""):
    print(("  OK    " if ok else "  ПЛОХО ") + name + (("  " + detail) if detail and not ok else ""))
    if not ok:
        FAILED.append(name)


# ======================================================================
def test_poisson_tail_precision():
    """P(X ≥ c) не должна упираться в пол при c >> λ.

    Было: хвост считался как 1 − CDF. Для c, заметно больших λ, CDF отличается
    от единицы меньше машинного эпсилона, разность обнулялась, и результат
    зажимался на 1e-12 — потолок ровно 39.86 бит. Всплеск в 20 событий и
    всплеск в 30 получали ОДИН И ТОТ ЖЕ скор.

    Эталон — рекуррентное суммирование хвоста в лог-пространстве, независимое
    от реализации в detector.py.
    """
    print("\n-- пуассоновский хвост --")

    def ref_sf(c, lam):
        """Σ_{k≥c} e^{−λ}λ^k/k! суммированием от старшего члена (без вычитания)."""
        if c <= 0:
            return 1.0
        log_t = -lam + c * math.log(lam) - math.lgamma(c + 1.0)
        t = math.exp(log_t)
        acc, k = t, c
        while t > acc * 1e-18 and k < c + 20000:
            t *= lam / (k + 1.0)
            acc += t
            k += 1
        return acc

    worst = 0.0
    for lam in (0.05, 0.5, 1.0, 2.0, 3.0, 10.0, 50.0):
        for c in list(range(1, 70)) + [120, 250]:
            ours = detector._poisson_sf(c, lam)
            if c <= lam:
                continue                        # левая часть считается иначе
            r = ref_sf(c, lam)
            if r > 1e-300:
                worst = max(worst, abs(ours - r) / r)
    check("хвост совпадает с прямым суммированием (отн. погрешность < 1e-10)",
          worst < 1e-10, f"худшая: {worst:.2e}")

    # именно то, что было сломано: разные всплески — разные числа
    b20 = -math.log2(detector._poisson_sf(20, 1.0))
    b30 = -math.log2(detector._poisson_sf(30, 1.0))
    check("всплеск 20 и всплеск 30 различимы (раньше оба 39.86 бит)",
          b30 - b20 > 40.0, f"20 -> {b20:.1f} бит, 30 -> {b30:.1f} бит")
    check("значения соответствуют точным (62.45 и 109.10 бит)",
          abs(b20 - 62.45) < 0.01 and abs(b30 - 109.10) < 0.01,
          f"{b20:.2f} / {b30:.2f}")

    # монотонность: чем больше всплеск, тем меньше вероятность
    prev, mono = 1.0, True
    for c in range(1, 80):
        v = detector._poisson_sf(c, 3.0)
        if v > prev + 1e-18:
            mono = False
        prev = v
    check("P(X ≥ c) не возрастает по c", mono)


def test_surprisal_floor():
    """Пол −log2(p) не должен быть достижим в обычной работе.

    Было: max(p, 1e-12) — потолок 39.86 бит, то есть ровно там, куда попадают
    настоящие всплески. Пол нужен только против p == 0.
    """
    print("\n-- неожиданность в битах --")
    check("surprisal(0) конечен", math.isfinite(detector._surprisal(0.0)))
    check("пол выше 1000 бит, а не 40",
          detector._surprisal(0.0) > 1000.0,
          f"{detector._surprisal(0.0):.1f}")
    check("1e-33 даёт ~109.6 бит, а не обрезается",
          abs(detector._surprisal(1e-33) - 109.62) < 0.01,
          f"{detector._surprisal(1e-33):.2f}")


def test_distributions_normalised():
    """Плотности обязаны суммироваться в единицу — иначе «биты» не биты."""
    print("\n-- нормировка распределений --")
    for hist in ([9, 10, 11], [23, 0, 1, 2], [14] * 50, []):
        v = detector._VonMisesHours()
        for h in hist:
            v.update(h)
        tot = sum(v.prob(h) for h in range(24))
        check(f"фон Мизес: Σp = 1 (история {len(hist)} набл.)", abs(tot - 1.0) < 1e-9,
              f"{tot:.12f}")

    v = detector._VonMisesHours()
    for _ in range(50):
        v.update(0)
    check("час цикличен: p(1) == p(23) при истории в полночь",
          abs(v.prob(1) - v.prob(23)) < 1e-12)
    check("час цикличен: соседи полуночи вероятнее полудня",
          v.prob(1) > 5 * v.prob(12))

    c = detector._Categorical()
    for x in ["a"] * 10 + ["b"] * 3 + ["c"]:
        c.update(x)
    vocab = {"a", "b", "c", "d", "e"}
    tot = sum(c.prob(x, vocab) for x in vocab)
    check("Дирихле: Σp по словарю = 1", abs(tot - 1.0) < 1e-12, f"{tot:.12f}")
    check("невиданное значение получает ненулевую вероятность",
          c.prob("e", vocab) > 0)


def test_wilson_exact_quantile():
    """Интервал Уилсона считается по точному квантилю, а не по 1.96.

    Эталон — значения statsmodels.proportion_confint(method='wilson'),
    зафиксированные числом: 41/55 -> [0.6169812871823414, 0.8418788522692710].
    """
    print("\n-- интервал Уилсона --")
    check("квантиль точный, а не 1.96",
          abs(stats.Z95 - 1.959963984540054) < 1e-15, f"{stats.Z95!r}")
    lo, hi = stats.wilson(41, 55)
    check("41/55 совпадает с эталоном statsmodels",
          abs(lo - 0.6169812871823414) < 1e-12 and abs(hi - 0.8418788522692710) < 1e-12,
          f"[{lo:.10f}, {hi:.10f}]")
    lo, hi = stats.wilson(0, 20)
    check("вырожденный случай 0/20 не выходит за [0,1]", lo == 0.0 and hi < 1.0)
    lo, hi = stats.wilson(20, 20)
    check("вырожденный случай 20/20 не выходит за [0,1]", hi == 1.0 and lo > 0.0)


def test_pr_auc_ties():
    """PR-AUC на связках: эталон — average precision по определению."""
    print("\n-- PR-AUC --")
    pos, neg = [1, 1, 1, 2, 2], [1, 1, 2, 3, 3, 3]
    check("совпадает с sklearn.average_precision_score (0.40606061)",
          abs(stats.pr_auc(pos, neg) - 0.4060606060606061) < 1e-12,
          f"{stats.pr_auc(pos, neg):.10f}")
    check("ROC-AUC на связках совпадает с sklearn (0.26666667)",
          abs(stats.roc_auc(pos, neg) - 0.26666666666666666) < 1e-12)
    check("база PR-AUC = доля класса", abs(stats.baseline_pr(5, 95) - 0.05) < 1e-12)


def test_fusion_monotone():
    """Согласие слоёв не может понижать риск.

    Историческая ошибка: складывались апостериорные лог-шансы без вычитания
    приора, поэтому приор входил n раз, и КАЖДЫЙ дополнительный слой тянул
    риск вниз — правило 0.70 плюс подтверждение модели давали 0.30.
    """
    print("\n-- слияние рисков --")
    one = detector.fuse([{"risk": 0.70}])
    two = detector.fuse([{"risk": 0.70}, {"risk": 0.55}])
    three = detector.fuse([{"risk": 0.70}, {"risk": 0.55}, {"risk": 0.50}])
    check("второй согласный слой не понижает риск", two >= one, f"{one} -> {two}")
    check("третий согласный слой не понижает риск", three >= two, f"{two} -> {three}")
    check("риск остаётся в [0,1]", all(0.0 <= x <= 1.0 for x in (one, two, three)))
    check("пустой список -> 0", detector.fuse([]) == 0.0)


def test_feature_vocabulary_sync():
    """Словарь действий и вектор признаков не могут разойтись.

    Дважды расходились: сначала на issue_* (3 действия), потом на 24 действия
    сразу — модель перестала различать больше половины словаря, всё уходило в
    act_unknown. Теперь ACTIONS выводится из taxonomy.OBSERVABLE.
    """
    print("\n-- синхронность словаря и признаков --")
    missing, extra = ml_features.check_taxonomy()
    check("ACTIONS покрывает taxonomy.OBSERVABLE", not missing, str(missing[:8]))
    check("в ACTIONS нет действий вне словаря", not extra, str(extra[:8]))
    check("длина вектора совпадает с FEATURES",
          len(ml_features.featurize({})) == len(ml_features.FEATURES))
    check("порядок ACTIONS детерминирован (sorted)",
          ml_features.ACTIONS == sorted(ml_features.ACTIONS))

    n = len(ml_features.ACTIONS)
    check(f"каждое из {n} действий имеет свой признак",
          all(("act_" + a) in ml_features.FEATURES for a in ml_features.ACTIONS))

    # действие из словаря НЕ должно помечаться как неизвестное
    idx = ml_features.FEATURES.index("act_unknown")
    known = ml_features.featurize({"action": sorted(taxonomy.OBSERVABLE)[0]})
    unknown = ml_features.featurize({"action": "не-существующее-действие"})
    check("известное действие не попадает в act_unknown", known[idx] == 0.0)
    check("неизвестное действие помечается act_unknown", unknown[idx] == 1.0)


def main():
    print("=" * 70)
    print("  РЕГРЕССИИ ЧИСЛЕННОГО АППАРАТА")
    print("=" * 70)
    test_poisson_tail_precision()
    test_surprisal_floor()
    test_distributions_normalised()
    test_wilson_exact_quantile()
    test_pr_auc_ties()
    test_fusion_monotone()
    test_feature_vocabulary_sync()
    print("-" * 70)
    if FAILED:
        print(f"  ПРОВАЛЕНО: {len(FAILED)}")
        for f in FAILED:
            print("     -", f)
        return 1
    print("  Численный аппарат корректен.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
