# -*- coding: utf-8 -*-
"""ОБЩЕЕ СОСТОЯНИЕ И ХЕЛПЕРЫ КОНСОЛИ ЗАЩИТЫ.

Единственное место, где живут объекты, общие для всех разделов: коррелятор,
накопленная статистика потока, замок, кэш приглушённых правил, загрузчик
шаблонов. Разделы (console_app/*.py) импортируют их отсюда по имени.

Почему это безопасно при импорте по имени, а не через геттеры: ни один объект
здесь НЕ ПЕРЕПРИСВАИВАЕТСЯ после создания. Меняется только их содержимое
(_STATE — словарь, _COR — объект со своими полями). Проверка в console.py
раньше держалась на том же допущении, просто неявно: в файле не было ни одного
оператора global.
"""
import os.path as _os_path
import sys
import time
import json
import threading
import collections
from datetime import datetime, timedelta

from flask import jsonify

import config
import eventstore
import run_defense
import correlator as correlator_mod
import detector as detector_mod
import red_team
import soclog
import logging as _logging

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

#: Общая поверхность консоли. Перечислено ЯВНО, потому что `import *`
#: по умолчанию не переносит имена с подчёркиванием, а состояние здесь
#: именно такое (_COR, _STATE, _LOCK). Список заодно документирует, чем
#: разделы имеют право пользоваться.
__all__ = [
    "ROOT", "_TPL_DIR", "_TPL_CACHE", "_tpl", "_flog", "CURSOR", "_LOGIN_FAILS",
    "_PUBLIC_PATHS", "_COR", "_SUPPRESS", "FP_MUTE_THRESHOLD",
    "rule_verdict_stats", "muted_rules", "_LOCK", "_STATE", "_repo",
    "_MUTED_CACHE", "REPLAY_EVENTS", "_engine", "_jsonsafe", "_TACTIC_RU",
    "_WF_STATUSES", "SNAPSHOT_PERIOD_S", "_SNAP", "_HEALTH", "_DEMO",
    "_EXECM"
]

# =======================================================================
#  ШАБЛОНЫ
# =======================================================================
# Раньше HTML страниц лежал прямо в этом файле строковыми константами: одна
# только DASH занимала 144 КБ (2100 строк) и делала модуль нечитаемым — логика
# ингеста, детектирования и корреляции терялась между разметкой и CSS.
# Теперь страницы лежат в templates/ обычными .html-файлами: их можно открыть
# в редакторе с подсветкой, отдать на правку вёрстки и посмотреть diff.
#
# Свой загрузчик, а не render_template Flask: шаблоны здесь статические
# (данные подтягивает JS через /api/*), поэтому движок шаблонов не нужен,
# а лишняя зависимость от структуры каталогов Flask — не нужна тем более.
#: Корень ПРОЕКТА, а не пакета. Пакет лежит на уровень глубже, поэтому
#: dirname(__file__) указывал бы в console_app/ — и шаблоны, и results/
#: искались бы не там. Единственная точка вычисления корня на всю консоль.
ROOT = _os_path.dirname(_os_path.dirname(_os_path.abspath(__file__)))

_TPL_DIR = _os_path.join(ROOT, "templates", "console")

_TPL_CACHE = {}

def _tpl(name):
    """Прочитать шаблон. Кэш в памяти, но сбрасывается при правке файла.

    Раньше кэш был вечным: перезагрузчик Flask перезапускает процесс
    только на изменение .py, поэтому правки вёрстки не появлялись в
    браузере до ручного перезапуска — и это выглядело так, будто
    правка не сработала.
    """
    path = _os_path.join(_TPL_DIR, name)
    try:
        mtime = _os_path.getmtime(path)
    except OSError:
        mtime = 0
    hit = _TPL_CACHE.get(name)
    if hit and hit[0] == mtime:
        return hit[1]
    with open(path, encoding="utf-8") as f:
        text = f.read()
    _TPL_CACHE[name] = (mtime, text)
    return text

_flog = _logging.getLogger("console")

CURSOR = "console"

# =======================================================================
#  АУТЕНТИФИКАЦИЯ
# =======================================================================
# Раньше консоль защиты была открыта полностью: 35 маршрутов без единой
# проверки, включая POST /api/red/launch (запуск атакующей кампании),
# POST /api/incident/<id>/respond (действия реагирования) и маршруты,
# запускающие подпроцессы. Консоль среды (webapp.py :8787) при этом логин
# требовала — то есть защищённой была витрина, а не пульт управления.
#
# Учётные данные общие с консолью среды (config.WEB_ADMIN_USER/PASS), чтобы
# аналитик не держал два пароля.
_LOGIN_FAILS = {"n": 0, "until": 0.0}

#: Маршруты, доступные без сессии.
_PUBLIC_PATHS = {"/login", "/logout", "/healthz"}

_COR = correlator_mod.Correlator(window_min=180)

_SUPPRESS = detector_mod.Suppressor()   # против флуда UEBA-всплесков в ленте

# Detection Engineering: правила, которые аналитик подтвердил как ложные.
# 3+ подтверждённых FP -> правило глушится (алерты не поднимают инцидент).
FP_MUTE_THRESHOLD = 3

def rule_verdict_stats():
    """rule_id -> (сколько FP-инцидентов, сколько TP-инцидентов) по вердиктам.

    Считаем и подтверждения, и опровержения. Раньше считались только FP, и
    правило глушилось по трём отметкам независимо от того, сколько настоящих
    атак оно поймало. Многошаговая кампания поднимает пять-шесть правил
    разом, поэтому ТРИ ложных инцидента гасили сразу пять правил — включая
    те, что работают с точностью 87%. Аналитик, честно разметивший шум,
    выключал детект.
    """
    import collections as _c
    fp = _c.Counter(); tp = _c.Counter()
    try:
        stat = eventstore.all_incident_status()
    except Exception:
        # Отказ хранилища здесь не безобиден: без вердиктов «живая точность»
        # на дашборде молча схлопывается в ноль, и это читается как «детектор
        # ничего не ловит», а не как «база недоступна».
        _flog.error("не удалось прочитать вердикты инцидентов — "
                    "точность детектирования будет показана без них",
                    exc_info=True)
        return fp, tp
    with _LOCK:
        incs = list(_COR.incidents.values())
    for i in incs:
        v = (stat.get(i["id"]) or {}).get("verdict")
        if v not in ("fp", "tp"):
            continue
        seen = set()
        for a in i["alerts"]:
            rid = a.get("rule_id")
            if rid and rid not in seen:
                seen.add(rid)
                (fp if v == "fp" else tp)[rid] += 1
    return fp, tp

def muted_rules():
    """rule_id -> число подтверждённых FP, но только для правил, которые
    глушить безопасно.

    Правило считается шумным, если ложных отметок у него не меньше порога И
    при этом ложных строго больше, чем подтверждённых атак. Правило, которое
    поймало настоящую атаку столько же раз или чаще, не выключается: цена
    пропуска выше цены лишней тревоги.
    """
    fp, tp = rule_verdict_stats()
    out = type(fp)()
    for rid, n in fp.items():
        if n >= FP_MUTE_THRESHOLD and n > tp.get(rid, 0):
            out[rid] = n
    return out

_LOCK = threading.Lock()

_STATE = {
    "alerts": collections.deque(maxlen=800),
    "processed": 0, "alerts_total": 0,
    "by_actor": collections.Counter(),
    "by_repo": collections.Counter(),
    "by_tactic": collections.Counter(),
    "fired_tech": collections.Counter(),   # технике -> сколько раз сработала
    "fired_rule": collections.Counter(),   # rule_id -> сколько раз
    "muted_hits": 0,                       # сколько сработок отброшено FP-тюнингом
    "started": time.time(),
    "running": False,
    "mttd_sum": 0.0, "mttd_n": 0,
}

def _repo(v):
    """Имя репозитория для показа.

    В журнале есть старые события, где вместо названия лежит голый id
    проекта («6»): их писали до того, как справочник репозиториев стал
    полным. Реплей поднимает такие события заново, поэтому нормализуем
    на границе выдачи — в самом журнале ничего не переписываем.
    События без репозитория (например, создание API-токена) остаются
    пустыми: это честно, действие не привязано к коду.
    """
    if v is None or v == "":
        return None
    s = str(v)
    if s.isdigit():
        try:
            name = config.repo_name(int(s))
            if name and not str(name).isdigit():
                return name
        except (ValueError, KeyError):
            # Ожидаемый исход: id нет в справочнике (репозиторий пересоздали
            # или удалили). Показываем сам id — это честнее прочерка.
            pass
        except Exception:
            # Всё остальное — неожиданно и должно быть видно, иначе поле
            # «репозиторий» тихо деградирует до чисел по всему интерфейсу.
            _flog.error("сбой разрешения имени репозитория по id",
                        exc_info=True, extra={"ctx": {"id": s}})
    return s

_MUTED_CACHE = {"rules": {}, "ts": 0.0}

REPLAY_EVENTS = 6000   # сколько событий переигрывать при старте

def _engine():
    return run_defense._ENGINE

def _jsonsafe(o):
    if isinstance(o, dict):
        return {k: _jsonsafe(v) for k, v in o.items()}
    if isinstance(o, (set, frozenset)):
        return sorted(_jsonsafe(x) for x in o)
    if isinstance(o, (list, tuple)):
        return [_jsonsafe(x) for x in o]
    return o

_TACTIC_RU = {
    "reconnaissance": "разведка", "initial-access": "первичный доступ",
    "execution": "выполнение", "persistence": "закрепление",
    "privilege-escalation": "повышение привилегий", "defense-evasion": "обход защиты",
    "credential-access": "доступ к учётным данным", "discovery": "разведка внутри",
    "lateral-movement": "боковое перемещение", "collection": "сбор данных",
    "exfiltration": "вывод данных", "impact": "воздействие",
}

# === Воркфлоу аналитика: статусы инцидентов, SLA, вердикты ==================
_WF_STATUSES = ("new", "investigating", "contained", "closed")

# Период пересчёта метрик и состояние последнего прогона. Состояние
# отдаётся в /api/trends, чтобы на экране было видно, когда цифры
# обновлялись и когда обновятся снова: без этого «70%» на графике
# невозможно ни с чем соотнести — может, посчитано минуту назад, а может,
# висит с прошлого запуска.
SNAPSHOT_PERIOD_S = 300

_SNAP = {"last": None, "next": None, "running": False, "error": None, "count": 0}

# --- Health: строка здоровья (Мир жив? / события / Ollama / авто-триаж) -----
_HEALTH = {"ollama": None, "ts": 0.0}

# ----------------------------------------------------------------------
# --- Онбординг: демо-генератор и статус 5 шагов «счастливого пути» ----------
_DEMO = {"running": False, "msg": "", "rc": None}

# --- Executive Overview: страница для комиссии + метрики в подпроцессе -----
_EXECM = {"running": False, "data": None, "ts": 0.0, "err": ""}

