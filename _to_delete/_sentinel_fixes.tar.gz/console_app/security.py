# -*- coding: utf-8 -*-
"""Вход, сессия и заголовки безопасности

Часть консоли защиты. Вынесено из console.py: там 1841 строка держала
маршруты, ингест, триаж и сборку отчётов в одном файле, и правка одного
раздела требовала удерживать в голове все остальные.

Состояние и общие хелперы — в console_app.core, оно ЕДИНСТВЕННОЕ на процесс
и импортируется по имени: объекты (_COR, _STATE, _LOCK) создаются один раз
при импорте core и никогда не переприсваиваются, поэтому у всех разделов
общий экземпляр, а не копии.
"""
import sys
import time
import json
import threading
import collections
from datetime import datetime, timedelta

from flask import Blueprint, jsonify, request, session, redirect, url_for, Response

import config
import eventstore
import run_defense
import correlator as correlator_mod
import detector as detector_mod
import red_team
import soclog
from attack_matrix import ATTACK

from .core import *          # noqa: F401,F403  — общее состояние консоли
from . import core

bp = Blueprint("security", __name__)

@bp.before_app_request
def _require_auth():
    """Единая точка контроля доступа.

    Реализовано через before_request, а не декоратором на каждом маршруте:
    декоратор легко забыть на новом маршруте, и дыра появится незаметно.
    Здесь же закрыто всё по умолчанию — новый маршрут защищён автоматически.
    """
    p = request.path or "/"
    if p in _PUBLIC_PATHS or p.startswith("/static/"):
        return None
    if session.get("user"):
        return None
    if p.startswith("/api/"):
        return jsonify({"error": "auth", "detail": "требуется вход"}), 401
    return redirect(url_for("security.login"))

@bp.after_app_request
def _security_headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "no-referrer")
    resp.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; style-src 'self' 'unsafe-inline'; "
        "script-src 'self' 'unsafe-inline'; img-src 'self' data:; "
        "connect-src 'self'")
    return resp

@bp.route("/healthz")
def healthz():
    return jsonify({"ok": True})

@bp.route("/login", methods=["GET", "POST"])
def login():
    import hmac
    error = ""
    if request.method == "POST":
        now = time.time()
        if now < _LOGIN_FAILS["until"]:
            error = "Слишком много попыток — подождите немного"
        else:
            u_ok = hmac.compare_digest(request.form.get("username", ""),
                                       config.WEB_ADMIN_USER)
            p_ok = hmac.compare_digest(request.form.get("password", ""),
                                       config.WEB_ADMIN_PASS)
            if u_ok and p_ok:
                _LOGIN_FAILS["n"] = 0
                session["user"] = config.WEB_ADMIN_USER
                session.permanent = True
                return redirect(url_for("overview.index"))
            _LOGIN_FAILS["n"] += 1
            if _LOGIN_FAILS["n"] >= 5:
                _LOGIN_FAILS["until"] = now + 15
                _LOGIN_FAILS["n"] = 0
            time.sleep(0.5)
            error = "Неверный логин или пароль"
    return _tpl("login.html").replace("{{ERROR}}", error)

@bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("security.login"))

@bp.app_errorhandler(Exception)
def _unhandled(e):
    """Любая необработанная ошибка — в errors.log с полным трейсбеком."""
    from werkzeug.exceptions import HTTPException
    if isinstance(e, HTTPException):
        return e
    _flog.error("необработанная ошибка в маршруте %s %s",
                request.method, request.path, exc_info=True,
                extra={"ctx": {"path": request.path, "method": request.method,
                               "args": dict(request.args)}})
    return jsonify({"error": "internal", "detail": str(e)[:300]}), 500

